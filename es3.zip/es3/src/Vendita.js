import React from 'react';

function Vendita({oncarica, onvendita}) {
	return <div>
			<button type="button" onclick={oncarica}>Carica da file</button>
			<button type="button" onclick={onvendita}>Vendi prodotti random</button>
		</div>
}

export default Vendita
