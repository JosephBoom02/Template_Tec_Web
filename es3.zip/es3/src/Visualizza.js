import React from 'react';

function Visualizza({prod_venduti, calcProfitto}) {
	const list = prod_venduti.map(a => <li>{a.nome} - {a.quantita}</li>)
	return <div>
		<h2>List prodotti venduti</h2>
			<ul>
				{list}
			</ul>
			<button type="button" onclick={calcprofitto}>Calcola Profitto</button>
		</div>
}

export default Visualizza
