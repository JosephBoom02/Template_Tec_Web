import React from 'react';

function Profitto({profitto}) {
	const list = profitto.map(a => <li>{a.nome} - {a.profitto}</li>)
	const totale = profitto.reduce((prev, curr) => prev + curr.profitto)
	const media = totale / profitto.length
	return <div>
			<h2>Profitto:</h2>
			<ul>
				{list}
			</ul>
			<h4>Totale profitto: {totale}</h4>
			<h4>Media profitto: {media}</h4>
		</div>
}

export default Profitto
