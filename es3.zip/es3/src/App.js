import React from 'react';
import Vendita from './Vendita.js'
import Visualizza from './Visualizza.js'
import Profitto from './Profitto.js'
 


class App extends React.Component {
	constructor() {
		super()
		this.state = {
			catalogo: [ /*
					{ 
						prodotto: { 
							nome: "a", 
							prezzo_cliente: 10,
							prezzo_fornitore: 5
						},
						quantita: 0
					} */
				],
			prod_venduti: [ /*{ nome: "a", quantita: 10}*/ ],
			profitto: [ /* { nome: "a", profitto: 10*/ ],
			newProfitto: [ /* { nome: "a", profitto: 10*/ ]
		}
	}

	caricaJson = () => {
		import {dataJson} from "./data"
		this.setState({ catalogo: dataJson })
	}

	calcProfitto = () => {
		this.setState(prev => ({ profitto: prev.newProfitto}))
	}

	venditaCasuale = (prod) => {
		let quantita = Math.floor(Math.random() * 5)
		this.setState(prev => {
			const newCatalogo = prev.catalogo.map(a => {
				if (a.prodotto === prod) {
					if (quantita < a.quantita) {
						a.quantita -= quantita
						return a
					} else {
						/* side effect, pay attenction */
						quantita = a.quantita
						return null
					}
				} else {
					return a
				}}).filter(a => a != null)
			const newVenduti = prev.prod_venduti.push({ nome: prod.nome, quantita: quantita})
			return {
				profitto: prev.profitto,
				catalogo: newCatalogo,
				prod_venduti: newVenduti,
				newProfitto: newProfitto
			}
		})
	}

	render() {
		return <div>
				<Vendita oncarica={this.caricaJson} onvendita={this.venditaCasuale}/>
				<Visualizza { ...this.state} calcProfitto={this.calcProfitto}/>
				<Profitto { ...this.state}/>
			</div>
	}
}

export default App

