/**
 * 
 */

function parsificaJson(response){ //esempio classe Risultato attributi ServerCount,ServerTime,BeanCount,BeanTime
	var risultato = JSON.parse(response);
	var output = "<p> Risultato Server : <br/> Testo modificato :"+ risultato.testo+"<br/> Lunghezza testo:"+ risultato.occorrenze +"</p>";
	console.log(output);
	return output;
}

function callback(xhr){
	if(xhr.readyState === 2){
		//Richiesta inviata...
	}
	else if(xhr.readyState === 3){
		//Ricezione risposta...
	}
	else if(xhr.readyState === 4){
		if(xhr.status === 200){
			var output=parsificaJson(xhr.responseText);	// fai quello che devi fare	
			document.getElementById("result").innerHTML=output;
		}
		else{
			document.getElementById("result").innerHTML="<p>ops qualcosa è andato storto, codice di ritorno="+xhr.status+"</p>"
		}
	}
}

function ajaxJson(xhr,inserito){
	
	xhr.onreadystatechange = function () { callback(xhr); };
	
	try{
		xhr.open("post","./J1.jsp",true); // per get xhr.open("get","nomeservlet?attributo1=valore&attributo2=valore...
	}
	catch(e){
		alert(e);
	}
	console.log("aperta ajax");
	xhr.setRequestHeader("connection","close");
	var argument = "messaggio="+inserito; // esempio di chiamata post
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded"); // fondamentale per indicare al server il tipo //encoded 			//dei dati passati
	console.log(argument);
	xhr.send(argument);
}


function iframe(){
	alert("Impossibile effettuare l'operazione, il tuo browser è troppo vecchio");
}

function doAjax(inserito){
	var xhr = new XMLHttpRequest();
	if(xhr)
		ajaxJson(xhr,inserito);
	else
		iframe();
}

 function validate(elemento){
	 var inserito = elemento.value;
	 console.log(inserito);
	 var lastChar = inserito.charAt(inserito.length-1);
	 if(lastChar === '£'){
		 inserito=inserito.slice(0,inserito.length-1);
		 inserito= inserito.trim();
		 elemento.value = inserito;
		 if(inserito === ''){
			 alert("devi inserire qualcosa!");
		 }
		 else{
			 elemento.value="";
			 doAjax(inserito);
		 }
	 }
	 else{
		 if(inserito.length > 1000){
			 elemento.value = inserito.slice(0,1000);
		 }
		 else{
			 var regexMinuscoliMaiuscoli = /^([a-zA-Z]+\s*)*[a-zA-Z]+\s*$/;
			 if(!regexMinuscoliMaiuscoli.test(inserito)){
				 elemento.value = inserito.slice(0,inserito.length-1);
			 }
		 }
	 }
	 
 }