package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.*;

import beans.Risultato;

public class S2 extends HttpServlet{

	private static final long serialVersionUID = 1L;
	private static Map <String,LocalDateTime> tempoSessione;
	private static Map <String,Integer> numeroRichieste;
	private Gson gson;
	 
	public void init(ServletConfig config)throws ServletException {
		super.init(config);
		tempoSessione = new HashMap <String,LocalDateTime>();
		numeroRichieste = new HashMap <String,Integer>();
		this.getServletContext().setAttribute("tempoSessione", tempoSessione);
		this.getServletContext().setAttribute("numeroRichieste", numeroRichieste);
		gson = new Gson();
	}
	
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws  ServletException,IOException{
		doPost(request,response);
	}
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		if(!tempoSessione.containsKey(request.getSession().getId())) {
			tempoSessione.put(request.getSession().getId(),LocalDateTime.now());
			numeroRichieste.put(request.getSession().getId(),1);
			System.out.println(1);
		}
		else {
			tempoSessione.replace(request.getSession().getId(), LocalDateTime.now());
			int tentativi = numeroRichieste.get(request.getSession().getId());
			tentativi++;
			System.out.println(tentativi);
			numeroRichieste.put(request.getSession().getId(),tentativi);
		}
		tempoSessione.put(request.getSession().getId(),LocalDateTime.now());
		if(request.getAttribute("messaggio") == null) {
			System.out.println("Attributo non trovato");
			response.sendRedirect("./errors/notfound,html");
		}
		else {
			String messaggio = (String)request.getAttribute("messaggio");
			int bond = 'z'-'a';
			Random r = new Random();
			int scelta = r.nextInt(bond);
			char carScelto = (char)('a' +(char)scelta);
			String newTesto="";
			for(char temp : messaggio.toCharArray()){
				if(Character.toLowerCase(temp) != carScelto)
					newTesto += temp;
			}
			Risultato ris = new Risultato(newTesto,newTesto.length());
			response.getWriter().println(gson.toJson(ris));
			System.out.println("Inviato");
		}
	}
		
}
