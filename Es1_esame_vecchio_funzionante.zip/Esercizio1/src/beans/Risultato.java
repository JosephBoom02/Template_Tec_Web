package beans;

public class Risultato {
	private String testo;
	private int occorrenze;
	
	public Risultato(String testo, int occorrenze) {
		super();
		this.testo = testo;
		this.occorrenze = occorrenze;
	}

	public String getTesto() {
		return testo;
	}

	public void setTesto(String testo) {
		this.testo = testo;
	}

	public int getOccorrenze() {
		return occorrenze;
	}

	public void setOccorrenze(int occorrenze) {
		this.occorrenze = occorrenze;
	}
}
