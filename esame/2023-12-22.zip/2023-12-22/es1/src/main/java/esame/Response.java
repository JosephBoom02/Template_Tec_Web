package esame;

public class Response {
	int countAuguri;
	int countFelici;
	public int getCountAuguri() {
		return countAuguri;
	}
	public void setCountAuguri(int countAuguri) {
		this.countAuguri = countAuguri;
	}
	public int getCountFelici() {
		return countFelici;
	}
	public void setCountFelici(int countFelici) {
		this.countFelici = countFelici;
	}
	
	public Response() {
		
	}

}
