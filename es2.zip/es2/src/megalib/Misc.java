package megalib;

import com.google.gson.Gson;
import megalib.exceptions.WrongParamsException;

import javax.servlet.ServletContext;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class Misc {

    public static void checkParamOrThrow(Map<String, ?> params, String toCheck) throws WrongParamsException {
        if (!params.containsKey(toCheck))
            throw new WrongParamsException("Parametri errati: manca " + toCheck);
    }

    public static void checkParamOrThrow(Map<String, ?> params, Collection<String> toCheck) throws WrongParamsException {
        if (!params.keySet().containsAll(toCheck)) {
            StringBuilder sb = new StringBuilder("Parametri errati: mancano {");
            String prefix = "";
            for (String s : toCheck){
                sb.append(prefix);
                sb.append(s);
                prefix = ",";
            }
            sb.append("}");
            throw new WrongParamsException(sb.toString());
        }
    }

    public static Map<String, String> getFirstParamOfMap(Map<String, String[]> orig){
            HashMap<String, String> newOne = new HashMap<>();
            for (String k : orig.keySet()){
                newOne.put(k, orig.get(k)[0]);
            }
            return newOne;
    }

    public static <T> T fetchFromGson(String path, ServletContext context, Type objClass) throws IOException {
            Path myObj = Path.of(context.getRealPath(path));
            String file = new String(Files.readAllBytes(myObj));
            Gson gson = new Gson();
            return gson.fromJson(file, objClass);
    }

    public static <T> T  fetchFromGson(Gson gson, String path, ServletContext context, Type objClass) throws IOException {
        Path myObj = Path.of(context.getRealPath(path));
        String file = new String(Files.readAllBytes(myObj));
        return gson.fromJson(file, objClass);
    }

    public static <T> T  fetchFromGson(Gson gson, String path, Type objClass) throws IOException {
        Path myObj = Path.of(path);
        String file = new String(Files.readAllBytes(myObj));
        return gson.fromJson(file, objClass);
    }

    public static <T> T randomElementFromSet(Random random, Set<T> set) {
        int rnd = random.nextInt(set.size());
        Iterator<T> iter = set.iterator();
        for (int i = 0; i < rnd; i++) {
            iter.next();
        }
        return iter.next();
    }

    public static <T> Set<T> randomSubsetFromSet(Random random, Set<T> set, int howMany) {
        Set<T> ret = new HashSet<>();
        int rnd;
        Iterator<T> iter;
        while (ret.size() < howMany) {
            rnd = random.nextInt(set.size());
            iter = set.iterator();
            for (int i = 0; i < rnd; i++) {
                iter.next();
            }
            ret.add(iter.next());
        }
        return ret;
    }

}
