package megalib.datatypes;

public class Pair<T, S> {
    private T t;
    private S s;

    public Pair(T t, S s) {
        this.t = t;
        this.s = s;
    }
    public Pair() {}

    public T get1() {
        return t;
    }

    public void set1(T t) {
        this.t = t;
    }

    public S get2() {
        return s;
    }

    public void set2(S s) {
        this.s = s;
    }

    public T getT() {
        return t;
    }

    public void setT(T t) {
        this.t = t;
    }

    public S getS() {
        return s;
    }

    public void setS(S s) {
        this.s = s;
    }
}
