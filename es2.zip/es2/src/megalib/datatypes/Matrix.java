package megalib.datatypes;

import java.util.ArrayList;

public class Matrix extends ArrayList<ArrayList<Integer>>{
    private boolean[] seen;
    private boolean first = true;
    private Matrix[] slices;


    public Matrix() {
        super();
        seen = new boolean[4];
    }

    /*
            0 0 1 1
            0 0 1 1
            2 2 3 3
            2 2 3 3
         */
    public Matrix[] splitInFour() {
        Matrix[] ret = new Matrix[4];
        for (int z = 0; z < 4; z++) {
            ret[z] = new Matrix();
            int rows = this.size() / 2;
            for (int i = 0; i < rows; i++) {
                int cols = this.get(i).size() / 2;
                ArrayList<Integer> tmpRow1 = new ArrayList<>(cols);
                for (int j = 0; j < cols; j++) {
                    tmpRow1.add(this.get(i + rows * Math.floorDiv(z, 2)).get(j + cols * (z % 2)));
                }
                ret[z].add(tmpRow1);
            }
        }
        return ret;
    }

    /*
        true: got all slices
        false: still not complete
     */
    public boolean populateFromSplit(int slice, Matrix smaller) {
        seen[slice] = true;
        if (first) {
            slices = new Matrix[4];
            first = false;
        }
        slices[slice] = smaller;

        boolean all = seen[0] && seen[1] && seen[2] && seen[3];
        if (all) {
            for (int z = 0; z < 4; z += 2) {
                for (int i = 0; i < slices[z].size(); i++) {
                    this.add(slices[z].get(i));
                    this.get(this.size() - 1).addAll(slices[z + 1].get(i));
                }
            }
            slices = null;
            first = true;
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String prefix;
        for (ArrayList<Integer> row : this) {
            prefix = "";
            for (Integer i : row) {
                sb.append(prefix);
                sb.append(i);
                prefix = ", ";
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}
