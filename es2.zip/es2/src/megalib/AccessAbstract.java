package megalib;

import megalib.datatypes.Admin;
import megalib.datatypes.Pair;
import megalib.datatypes.Utente;
import megalib.exceptions.WrongParamsException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public abstract class AccessAbstract<utenteClass extends Utente> extends HttpServlet {
    public enum TipoAccesso {LOG, REG, CHANGE, LOGOUT}
    protected final ArrayList<utenteClass> utenti;
    private final ArrayList<String> expectedParams;
    private final Class<utenteClass> utenteClassClass;
    protected final Admin admin;

    public abstract boolean otherChecks(utenteClass newU, Map<String, String> params) throws WrongParamsException;

    /*
        Boolean ->  loggedIn or not
        String -> dispatch location
     */
    public abstract Pair<Boolean, Optional<String>> postLogin(utenteClass newU, Map<String, String> params) throws WrongParamsException;

    public static boolean isLoggedIn(HttpServletRequest request) {
        return request.isRequestedSessionIdValid()
                && request.getSession().getAttribute("isLoggedIn") != null
                && (boolean) request.getSession().getAttribute("isLoggedIn");
    }

    /* type parameter cant get constructor for some reason */
    public AccessAbstract(Class<utenteClass> utenteClassClass) throws NoSuchMethodException, IllegalAccessException, InstantiationException, InvocationTargetException {
        this.utenteClassClass = utenteClassClass;
        utenti = new ArrayList<>();
        admin = new Admin("admin", "yolo");
        expectedParams= new ArrayList<>(List.of("username", "password"));
    }

    private static <T extends Utente> void setAndForward(
            HttpServletRequest req,
            HttpServletResponse resp,
            boolean logged,
            T utente,
            String message)   throws  ServletException, IOException {
        setAndForward(req, resp, logged, utente, message, "/login/result.jsp");
    }

    private static <T extends Utente> void setAndForward(
                HttpServletRequest req,
                HttpServletResponse resp,
                boolean logged,
                T utente,
                String message,
                String dispatchLoc)   throws  ServletException, IOException{
        req.getSession().setAttribute("isLoggedIn", logged);
        req.getSession().setAttribute("utente", logged ? utente : null);
        req.setAttribute("resString", message);
        req.setAttribute("resVal", logged);
        RequestDispatcher disp = req.getRequestDispatcher(req.getContextPath() + dispatchLoc);
        disp.forward(req, resp);
    }

    private void handleAdmin(Map<String, String> params, TipoAccesso tipo, String username, String password, HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (tipo.equals(TipoAccesso.REG)) {
            setAndForward(req, resp, false, null, "utente già esistente");
        } else if (tipo.equals(TipoAccesso.LOG)) {
            if (admin.getUsername().equals(username) && admin.getPassword().equals(password))
                setAndForward(req, resp, true, admin, "tutto ok");
            else
                setAndForward(req, resp, false, null, "nome utente o password sbagliata");
        } else if (tipo.equals(TipoAccesso.CHANGE)) {
                Misc.checkParamOrThrow(params, "newPassword");
                String newPassword = params.get("newPassword");
                if (admin.getUsername().equals(username) && admin.getPassword().equals(password)){
                    admin.setPassword(newPassword);
                    setAndForward(req, resp, true, admin, "tutto ok");
                } else {
                    setAndForward(req, resp, false, null, "nome utente o password sbagliata");
                }
        } else if (tipo.equals(TipoAccesso.LOGOUT)) {
            setAndForward(req, resp, false, null, "logged out");
        } else {
            throw new WrongParamsException("tipo richiesta?");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            Map<String, String> params = Misc.getFirstParamOfMap(req.getParameterMap());

            Misc.checkParamOrThrow(params, expectedParams);
            TipoAccesso tipo = TipoAccesso.valueOf(params.get("type"));
            String username = params.get("username");
            String password = params.get("password");

            if (username.equals(admin.getUsername())) {
                handleAdmin(params, tipo, username, password, req, resp);
                return;
            }

            if (tipo.equals(TipoAccesso.REG)) {
                boolean giaEsiste = utenti.stream()
                        .anyMatch(g -> g.getUsername().equals(username));
                if (giaEsiste) {
                    setAndForward(req, resp, false, null, "utente già esistente");
                } else {
                    /* type parameter cant get constructor for some reason */
                    utenteClass newU = utenteClassClass.getDeclaredConstructor(String.class, String.class).newInstance(username, password);
                    if (otherChecks(newU, params)) {
                        utenti.add(newU);
                        setAndForward(req, resp, true, newU, "tutto ok");
                    } else {
                        setAndForward(req, resp, false, null, "other checks failed");
                    }
                }
            } else if (tipo.equals(TipoAccesso.LOG)) {
                Optional<utenteClass> ok =
                        utenti.stream().filter(u -> u.getUsername().equals(username) && u.getPassword().equals(password)).findFirst();
                if (ok.isPresent()){
                    Pair<Boolean, Optional<String>> postLoginRet = postLogin(ok.get(), params);
                    setAndForward(req, resp, postLoginRet.get1(), ok.get(), "tutto ok", postLoginRet.get2().orElse("/login/result.jsp"));
                } else {
                    setAndForward(req, resp, false, null, "nome utente o password sbagliata");
                }
            } else if (tipo.equals(TipoAccesso.CHANGE)) {
                Misc.checkParamOrThrow(params, "newPassword");
                String newPassword = params.get("newPassword");
                Optional<utenteClass> ok =
                        utenti.stream().filter(u -> u.getUsername().equals(username) && u.getPassword().equals(password)).findFirst();
                if (ok.isPresent()){
                    ok.get().setPassword(newPassword);
                    setAndForward(req, resp, true, ok.get(), "tutto ok");
                } else {
                    setAndForward(req, resp, false, null, "nome utente o password sbagliata");
                }
            } else if (tipo.equals(TipoAccesso.LOGOUT)) {
                setAndForward(req, resp, false, null, "logged out");
            } else {
                    throw new WrongParamsException("tipo richiesta?");
            }
        } catch (WrongParamsException e) {
            resp.sendError(400, "wrong request");
            e.printStackTrace();
        } catch (InstantiationException | InvocationTargetException | NoSuchMethodException | IllegalAccessException e) {
            resp.sendError(501, "someone used this wrong");
        }
    }
}
