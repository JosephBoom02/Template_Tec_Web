package megalib.exceptions;

import javax.servlet.ServletException;

public class WrongParamsException extends ServletException {

    public WrongParamsException(String s){
        super(s);
    }
}
