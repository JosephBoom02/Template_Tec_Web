package ws;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.HashSet;
import java.util.Map;

@ServerEndpoint("/wsTemplate")
public class WsEndpointTemplate {
    private static final Type jsonMapType = new TypeToken<Map<String, String>>(){}.getType();
    private Gson gson;
    private static final HashSet<Session> sessions = new HashSet<>();

    @OnOpen
    public synchronized void onOpen(Session session) throws IOException, EncodeException {
        gson = new Gson();
    }


    @OnMessage
    public synchronized void onMessage(String message, Session session) throws IOException, EncodeException {
        Map<String, String> req = gson.fromJson(message, jsonMapType);

    }

    @OnClose
    public synchronized void onClose(Session session) throws IOException, EncodeException {

    }

    @OnError
    public synchronized void onError(Session session, Throwable throwable) {
    }

}