package ws;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import megalib.datatypes.Matrix;
import megalib.Misc;
import megalib.datatypes.Pair;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.*;

@ServerEndpoint("/wsMatrix")
public class WsEndpointMatrixExample {
    private Gson gson;
    private static final HashSet<Session> sessions = new HashSet<>();
    private ArrayList<Pair<Matrix, Matrix>> jobs;
    private static final ArrayList<Matrix> results = new ArrayList<>();
    private static final Type fileJsonType = new TypeToken<ArrayList<Pair<Matrix, Matrix>>>(){}.getType();
    private static final Type reqJsonType = new TypeToken<Pair<Integer, Pair<Matrix, Matrix>>>(){}.getType();
    private static final Type respJsonType = new TypeToken<Pair<Integer, Matrix>>(){}.getType();
    private static int counter = 0;
    private final Random random;

    public WsEndpointMatrixExample() {
        jobs = new ArrayList<>();
        gson = new Gson();
        random = new Random();
        try {
            jobs = Misc.fetchFromGson(gson, "/home/yolo/Programmi/tekweb/lab/esercit/react_websocket/ws/es2/out/artifacts/yolo/data.json", fileJsonType);
            for (int i = 0; i < jobs.size(); i++) {
                results.add(new Matrix());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @OnOpen
    public synchronized void onOpen(Session session) throws IOException, EncodeException {
        try {
            gson = new Gson();
            sessions.add(session);
            System.out.println(sessions.size());
            if (sessions.size() >= 4) {
                Set<Session> chosen = Misc.randomSubsetFromSet(random, sessions, 4);
                Pair<Matrix, Matrix> tmp = jobs.get(counter);
                Matrix[] matA = tmp.get1().splitInFour();
                Matrix[] matB = tmp.get2().splitInFour();
                Pair[] splitted = new Pair[4];
                for (int i = 0; i < 4; i++)
                    splitted[i] = new Pair<>(matA[i], matB[i]);
                Iterator<Session> iter = chosen.iterator();
                for (int i = 0; iter.hasNext(); i++)
                    iter.next().getBasicRemote().sendText(gson.toJson(new Pair<>(i, splitted[i]), reqJsonType));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @OnMessage
    public synchronized void onMessage(String message, Session session) throws IOException, EncodeException {
        System.out.println(message);
        Pair<Integer, Matrix> resp = gson.fromJson(message, respJsonType);
        Matrix tmp = results.get(counter);
        if (tmp.populateFromSplit(resp.get1(), resp.get2())) {
            System.out.println(tmp.toString());
            counter++;
        }

    }

    @OnClose
    public synchronized void onClose(Session session) throws IOException, EncodeException {
        sessions.remove(session);
    }

    @OnError
    public synchronized void onError(Session session, Throwable throwable) {
        sessions.remove(session);
    }
}
