package me;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import megalib.Misc;
import megalib.datatypes.Utente;
import megalib.exceptions.NotLoggedInException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EndpointAPI extends HttpServlet {
    public static String servletPath = null;
    private Gson gson;
    private static final Type fileType = new TypeToken<ArrayList<String>>(){}.getType();
    private ArrayList<String> dizionario;


    @Override
    public void init() throws ServletException {
        gson = new Gson();
        servletPath = getServletContext().getRealPath(".");
        try {
            dizionario = Misc.fetchFromGson(gson, "dizionaio.txt", getServletContext(), fileType);
            getServletContext().setAttribute("sizeDizionario", dizionario.size());
        } catch (IOException e) {
            e.printStackTrace();
            throw new ServletException("cant load data");
        }
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        Map<String, String> params = Misc.getFirstParamOfMap(req.getParameterMap());
        for (String param : List.of("lettere", "concurrent")) {
            Misc.checkParamOrThrow(params, param);
        }
        Utente u = (Utente) req.getSession().getAttribute("utente");
        if (u == null)
            throw new NotLoggedInException();
        boolean concurrent = Boolean.parseBoolean(params.get("concurrent"));
        String lettere = params.get("lettere");
        if (concurrent) {
            Misc.checkParamOrThrow(params, "half");
            int half = Integer.parseInt(params.get("half"));
            List<String> fullArr = dizionario.stream().filter(w ->
                    w.contains(lettere.substring(0, 1)) && w.contains(lettere.substring(1, 2)) && w.contains(lettere.substring(2, 3))).collect(Collectors.toList());
            List<String> respArr = fullArr.subList(half * fullArr.size(), (half + 1) * fullArr.size());
            resp.getWriter().print(gson.toJson(respArr));
        } else {
            List<String> fullArr = dizionario.stream().filter(w ->
                    w.contains(lettere.substring(0, 1)) && w.contains(lettere.substring(1, 2)) && w.contains(lettere.substring(2, 3))).collect(Collectors.toList());
            resp.getWriter().print(gson.toJson(fullArr));
        }
    }
}
