const fromObjectToForm = (obj) => {
                ret = ""
                prefix = ""
                for (const [key, value] of Object.entries(obj)) {
                    ret += prefix + key + "=" + value
                    prefix = "&"
                }
                return ret
            }

/* fetch api post template
    data = {
        what: "fin",
    }
    fetch("/api", {
        method: "POST",
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: fromObjectToFrom(data)
    })
 */

const fetchGetParams = () => {
    const ret = {}
    const couples = window.location.search
        .substr(1)
        .split("&")
    couples.forEach((c) => {
        const v = c.split("=")
        ret[v[0]] = v[1]
    })
    return ret
}

/* timeout fetch the right way
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 5000)
    const res = await fetch('https://example.com', { signal: controller.signal })
    const body = await res.json()
    clearTimeout(timeoutId)
*/

/* easyier solution */
const timeoutPromise = (ms, promise) => {
  let timeout = new Promise((resolve, reject) => {
    let id = setTimeout(() => {
      reject('Timed out in '+ ms + 'ms.')
    }, ms)
  })

  return Promise.race([
    promise,
    timeout
  ])
}


/* split array:
    splitArr = (data) => {
        let rows = meta.rows / 2
        let cols = meta.cols / 2
        let resp = Array(4).fill(1).map(() => Array(2).fill(1).map(() => Array(rows).fill(1).map(() => Array(cols))))
        for (let z = 0; z < 4; z++) {
            for(let x = 0; x < 2; x++) {
                for (let i = 0; i < rows; i++) {
                    for (let j = 0; j < cols; j++) {
                        resp[z][x][i][j] = data[x][i + rows * (z % 2)][j + cols * Math.floor(z / 2)]
                    }
                }
            }
        }
        return resp
    }
 */


/*  ws example
    const ws = new WebSocket(`ws://\${window.location.host}/ws`);
    ws.onmessage = (msg) => {
        const msgObj = JSON.parse(msg.data)
        ws.send(JSON.stringify({ t: whoAmI, s: ret }))
    }
 */
