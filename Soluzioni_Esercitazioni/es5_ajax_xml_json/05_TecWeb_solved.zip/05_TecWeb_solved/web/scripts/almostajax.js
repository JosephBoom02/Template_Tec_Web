/*
 * Sostituzione dell'innerHTML
 * dell'elemento caratterizzato dall'id ricevuto
 */
function almostAJAX( elementId ) {
	myGetElementById( elementId ).innerHTML = 'Quasi <strong>AJAX</strong>...';
}
