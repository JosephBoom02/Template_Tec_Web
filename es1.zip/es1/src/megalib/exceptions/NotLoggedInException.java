package megalib.exceptions;

import javax.servlet.ServletException;

public class NotLoggedInException extends ServletException {

    /* 401 unauthorized */
    public NotLoggedInException(){
        super("Are you logged in?");
    }
}
