package megalib.datatypes;

import java.io.ObjectStreamException;
import java.util.HashMap;

public class Admin extends Utente{
    private final HashMap<String, Object> attributes;

    public Admin(String username, String password) {
        super(username, password);
        attributes = new HashMap<>();
    }

    public void putAttribute(String key, Object val) {
        attributes.put(key, val);
    }

    public Object getAttribute(String key) {
        return attributes.get(key);
    }
}
