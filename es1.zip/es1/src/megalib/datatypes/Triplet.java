package megalib.datatypes;

public class Triplet<T, S, U> {
    private T t;
    private S s;
    private U u;

    public Triplet(T t, S s) {
        this.t = t;
        this.s = s;
        this.u = u;
    }
    public Triplet() {}

    public T get1() {
        return t;
    }

    public void set1(T t) {
        this.t = t;
    }

    public S get2() {
        return s;
    }

    public void set2(S s) {
        this.s = s;
    }


    public U get3() {
        return u;
    }

    public void set3(U u) {
        this.u = u;
    }
}
