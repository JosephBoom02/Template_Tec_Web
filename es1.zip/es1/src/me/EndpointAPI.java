package me;

import com.google.gson.Gson;
import megalib.Misc;
import megalib.datatypes.Matrix;
import megalib.datatypes.Utente;
import megalib.exceptions.NotLoggedInException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EndpointAPI extends HttpServlet {
    public static String servletPath = null;
    private static int finished = 0;
    private static int started = 0;
    private static HashMap<HttpSession, Matrix> toSend;
    private Gson gson;
    Object changeThis;

    @Override
    public void init() throws ServletException {
        gson = new Gson();
        servletPath = getServletContext().getRealPath(".");
        try {
            changeThis = Misc.fetchFromGson(gson, "data.json", getServletContext(), Object.class);
        } catch (IOException e) {
            e.printStackTrace();
            throw new ServletException("cant load data");
        }
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        Req reqJson = gson.fromJson(req.getReader(), Req.class);
        Matrix respMatSmall = new Matrix();
        for (int i = 0; i < respMatSmall.size(); i++) {
            respMatSmall.add(i, new ArrayList<>());
            for (int j = 0; j < respMatSmall.get(i).size(); j++) {
                respMatSmall.get(i).add(j, reqJson.getMatA().get(i).get(j) + reqJson.getMatB().get(i).get(j));
            }
        }

        if (toSend.containsKey(req.getSession())) {
            finished++;
            Matrix respMat = toSend.get(req.getSession());
            respMat.populateFromSplitTwo(reqJson.getNum(), respMatSmall);
            resp.getWriter().print(gson.toJson(new Resp(respMat, "started: " + started + ", finished: " + finished)));

        } else {
            started++;
            Matrix tmpMat = new Matrix();
            tmpMat.populateFromSplitTwo(reqJson.getNum(), respMatSmall);
            toSend.put(req.getSession(), tmpMat);
            resp.getWriter().print(gson.toJson(new Resp(tmpMat, "started: " + started + ", finished: " + finished)));
        }

    }
}
