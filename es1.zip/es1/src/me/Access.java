package me;

import megalib.AccessAbstract;
import megalib.Misc;
import megalib.datatypes.Pair;
import megalib.datatypes.Utente;
import megalib.exceptions.WrongParamsException;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.Optional;

public class Access extends AccessAbstract<Utente> {

    public Access() throws NoSuchMethodException, IllegalAccessException, InstantiationException, InvocationTargetException {
        super(Utente.class);
    }

    @Override
    public boolean otherChecks(Utente newU, Map<String, String> params) throws WrongParamsException {
        return true;
    }

    @Override
    public Pair<Boolean, Optional<String>> postLogin(Utente newU, Map<String, String> params) throws WrongParamsException {
        return new Pair<>(true, Optional.empty());
    }
}
