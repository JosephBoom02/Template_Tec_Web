package me;

import megalib.datatypes.Matrix;

public class Resp {
    private Matrix mat;
    private String msg;


    public Resp(Matrix mat, String msg) {
        this.mat = mat;
        this.msg = msg;
    }

    public Matrix getMat() {
        return mat;
    }

    public String getMsg() {
        return msg;
    }
}
