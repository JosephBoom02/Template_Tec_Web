package me;

import megalib.datatypes.Matrix;

public class Req {
    private Matrix matA;
    private Matrix matB;
    private int num;

    public Matrix getMatA() {
        return matA;
    }

    public Matrix getMatB() {
        return matB;
    }

    public int getNum() {
        return num;
    }
}
